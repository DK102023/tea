export type ProductType = {
  image: string,
  title: string,
  price: string,
  description: string,
  id: number

}
