import {AfterViewInit, Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import 'jquery-ui-dist/jquery-ui';
import {PopupComponent} from "../../common/popup/popup.component";
import {PopupDelayComponent} from "../../common/popup-delay/popup-delay.component";
import {Subscription, timer} from "rxjs";
//import WOW from 'wowjs';

declare var WOW: any;
declare var $: any;

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit, AfterViewInit,OnDestroy {
  private popupSubscription: Subscription | null = null;
  @ViewChild(PopupComponent) popupComponent!: PopupComponent;

  constructor() { }

  ngOnInit(): void {
    // Инициализация WOW.js
    new WOW().init();
   // new WOW.WOW().init();

    // Инициализация Slick Carousel
    $(document).ready(() => {
      $('.slick-slider').slick({
        prevArrow: '.slick-prev',
        nextArrow: '.slick-next'
      });
    });

    // Таймер на 10 секунд
  /*  this.popupSubscription = timer(10000).subscribe(() => {
      this.popupComponent.openModal();
    });*/


  }

  ngAfterViewInit(): void {
    $( "#accordion" ).accordion();
  }

  ngOnDestroy(): void {
    // Отписываемся от таймера, если пользователь уходит с страницы
  //  this.popupSubscription?.unsubscribe();
  }

}
