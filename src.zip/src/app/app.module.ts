import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/common/header/header.component';
import { FooterComponent } from './components/common/footer/footer.component';
import { MainComponent } from './components/pages/main/main.component';
import { CatalogueComponent } from './components/pages/catalogue/catalogue.component';
import { OrderComponent } from './components/pages/order/order.component';
import { ProductComponent } from './components/pages/product/product.component';
import {HttpClientModule} from "@angular/common/http";
import {CatalogueItemComponent} from "./components/common/catalogue-item/catalogue-item.component";
import { ExerptFormatPipe } from './pipes/exerpt-format.pipe';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import { PopupComponent } from './components/common/popup/popup.component';
import { PopupDelayComponent } from './components/common/popup-delay/popup-delay.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MainComponent,
    CatalogueComponent,
    OrderComponent,
    ProductComponent,
    CatalogueItemComponent,
    CatalogueItemComponent,
    ExerptFormatPipe,
    PopupComponent,
    PopupDelayComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
