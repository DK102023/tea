import {Component, Input} from '@angular/core';
import 'jquery-ui-dist/jquery-ui';

declare var $: any;

@Component({
  selector: 'app-popup',
  templateUrl: './popup.component.html',
  styleUrls: ['./popup.component.css']
})
export class PopupComponent  {
  @Input() modalTitle: string = '';
  @Input() modalDescription: string = 'Посмотрите наши чайные коллекции';

  openModal() {
    // Открытие модального окна с использованием jQuery
    $('#popupModal').modal('show');
  }

  closeModal() {
    // Закрытие модального окна с использованием jQuery
    $('#popupModal').modal('hide');
  }

}
